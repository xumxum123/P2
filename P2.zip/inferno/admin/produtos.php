<?php
session_start();
include '../includes/db.php';
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$sql = "SELECT * FROM produtos";
$result = $conn->query($sql);

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM produtos WHERE id = $id");
    header('Location: produtos.php');
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Produtos</title>
    <style>

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    color: #333;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}

h1 {
    color: #007bff;
    margin-bottom: 20px;
    text-align: center;
}

a {
    text-decoration: none;
    color: #007bff;
    font-weight: bold;
    margin-bottom: 20px;
    display: inline-block;
    transition: color 0.3s;
}

a:hover {
    color: #0056b3;
}

table {
    width: 90%;
    border-collapse: collapse;
    margin-top: 20px;
    background: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

thead {
    background-color: #007bff;
    color: #fff;
}

thead th {
    padding: 10px;
    text-align: left;
    font-size: 16px;
}

tbody tr:nth-child(odd) {
    background-color: #f9f9f9;
}

tbody tr:nth-child(even) {
    background-color: #e9ecef;
}

tbody td {
    padding: 10px;
    font-size: 14px;
    text-align: left;
}

tbody tr:hover {
    background-color: #f1f1f1;
}

td a {
    text-decoration: none;
    padding: 5px 10px;
    color: #fff;
    background-color: #007bff;
    border-radius: 4px;
    transition: background-color 0.3s;
    margin-right: 5px;
}

td a:hover {
    background-color: #0056b3;
}

td a:nth-child(2) {
    background-color: #dc3545;
}

td a:nth-child(2):hover {
    background-color: #b02a37;
}

    </style>
</head>
<body>
    <h1>Gerenciar Produtos</h1>
    <a href="adicionar.php">Adicionar Novo Produto</a>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Preço</th>
                <th>Categoria</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($produto = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo $produto['id']; ?></td>
                    <td><?php echo $produto['nome']; ?></td>
                    <td>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></td>
                    <td><?php echo $produto['categoria']; ?></td>
                    <td>
                        <a href="editar.php?id=<?php echo $produto['id']; ?>">Editar</a>
                        <a href="produtos.php?delete=<?php echo $produto['id']; ?>">Excluir</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
